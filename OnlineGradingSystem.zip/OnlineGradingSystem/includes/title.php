<link rel="icon" type="image/x-icon" href="../img/logo.ico" />
  <title>MIES Grading System</title>
