<footer>
            <div class="copyright" align="center" >
                &copy; Copyright <strong><span>MIES</span></strong>. All Rights Reserved
            </div>  
        </footer>