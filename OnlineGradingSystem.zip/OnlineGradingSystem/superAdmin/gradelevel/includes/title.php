<link rel="icon" type="image/x-icon" href="<?php echo BASE_URL; ?>img/logo.ico" />
  <title>MIES Grading System</title>

